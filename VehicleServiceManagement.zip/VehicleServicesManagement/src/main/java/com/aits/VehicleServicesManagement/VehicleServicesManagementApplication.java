package com.aits.VehicleServicesManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleServicesManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleServicesManagementApplication.class, args);
	}

}
