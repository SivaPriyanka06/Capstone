package com.aits.VehicleServicesManagement.entity;

public enum Role {
	      ADMIN,SERVICE_ADVISOR
	

}
