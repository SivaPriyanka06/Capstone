package com.aits.PrepaidRechargeProject.entity;

public enum Role {
      ADMIN,USER
}
