package com.aits.PrepaidRechargeProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrepaidRechargeProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrepaidRechargeProjectApplication.class, args);
	}

}
